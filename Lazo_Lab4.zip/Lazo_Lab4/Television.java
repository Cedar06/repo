
public class Television {

	private String MANUFACTURER;
	private int SCREEN_SIZE;
	private boolean powerOn;
	private int channel;
	private int volume;
	
	/**
	 * Sets the defaults for Television object and takes in parameters to fill in
	 * MANUFACTURER and SCREEN_SIZE only once.
	 * @param brand: Sets constant brand
	 * @param size: Sets constant size
	 */
	public Television(String brand, int size) {
		MANUFACTURER = brand;
		SCREEN_SIZE = size;
		powerOn=false;
		channel = 2;
		volume = 20;
		
	}
	
	/**
	 * Changes the channel of the Television object to channel
	 * @param channel: Sets the channel to input
	 */
	public void setChannel(int channel) {
		this.channel = channel;
	}
	
	/**
	 * Changes the state of power of Television
	 */
	public void power() {
		powerOn = !powerOn;
	}
	
	/**
	 * Increments the volume of 1 of the Television obj
	 */
	public void increaseVolume() {
		volume++;
	}
	
	/**
	 * Decrements the volume of 1 of the Television obj
	 */
	public void decreaseVolume() {
		volume--;
	}
	
	/**
	 * Obtains the current channel of Television
	 * @return current channel
	 */
	public int getChannel() {
		return channel;
	}
	
	/**
	 * Obtains the current volume of Television
	 * @return current volume
	 */
	public int getVolume() {
		return volume;
	}

	/**
	 * Obtains the manufacturer of the Television (constant)
	 * @return the constant manufacturer
	 */
	public String getManufacturer() {
		return MANUFACTURER;
	}
	
	/**
	 * Obtains the screen size of the Television (constant)
	 * @return the constant screen size
	 */
	public int getScreenSize() {
		return SCREEN_SIZE;
	}
}
