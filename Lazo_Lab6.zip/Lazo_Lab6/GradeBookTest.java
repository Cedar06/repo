import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GradeBookTest {

	GradeBook one, two;
	
	@BeforeEach
	void setUp() throws Exception {
		
		one = new GradeBook(5);
		two = new GradeBook(5);
		one.addScore(98);
		one.addScore(76);
		one.addScore(54);
		two.addScore(2);
		two.addScore(6);
		two.addScore(9);
		two.addScore(1);
	}

	@AfterEach
	void tearDown() throws Exception {
		one = null;
		two = null;
	}

	@Test
	void testAddScore() {
		assertTrue("98.0 76.0 54.0 ".equals(one.toString()));
		assertEquals(3, one.getScoreSize());
		assertTrue("2.0 6.0 9.0 1.0 ".equals(two.toString()));
		assertEquals(4, two.getScoreSize());
	}


	@Test
	void testSum() {
		assertEquals(228,one.sum());
		assertEquals(18,two.sum());
	}

	@Test
	void testMinimum() {
		assertEquals(54,one.minimum());
		assertEquals(1,two.minimum());
	}

	@Test
	void testFinalScore() {
		assertEquals(174,one.finalScore());
		assertEquals(17,two.finalScore());
	}

}

