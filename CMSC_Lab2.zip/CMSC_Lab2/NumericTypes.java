import java.util.Scanner;

/**
   This program demonstrates how numeric types and operators behave in Java
*/
public class NumericTypes {
	public static void main (String [] args) {
		Scanner input = new Scanner(System.in);
		final int NUMBER = 2; // number of scores
		//int score1 = 100; // first test score
		//int score2 = 95; // second test score
		final int BOILING_IN_F = 212; // boiling temperature
		double fToC; // temperature in Celsius
		double average; // arithmetic average
		String output; // line of output to print out
		System.out.println("Enter the first score: ");		
		int score1=input.nextInt();								 	
		System.out.println("Enter the second score: ");		
		int score2=input.nextInt();	
		average = (score1 + score2) / (double)NUMBER;
		output = score1 + " and " + score2 + " have an average of " + average;	
		System.out.println(output);
		fToC = (BOILING_IN_F - 32) * (5.0/9);
		output = BOILING_IN_F + " in Fahrenheit is " + fToC + " in Celsius.";
		System.out.println(output);
		System.out.println("Enter another temperature: ");
		double tempIn = input.nextDouble();
		fToC = (5.0/9) * (tempIn - 32);
		output = tempIn + " in Fahrenheit is " + fToC + " in Celsius.";
		System.out.println(output);
		System.out.println("Goodbye"); // to show that the program is ended	
	}
}
