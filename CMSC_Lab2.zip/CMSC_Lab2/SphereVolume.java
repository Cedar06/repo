import java.util.Scanner;

public class SphereVolume {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a diameter of a sphere: ");
		double diam = input.nextDouble();
		double radius = diam/2.0;
		double vol = (Math.pow(radius, 3)*Math.PI*(4.0/3));
		System.out.println("The volume of the sphere is: "+vol);
		
		


	}

}
