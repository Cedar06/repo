/**
 * CourseDBManager creates a database for courses using a course structure.
 * Data is able to be entered manually or through a file, and courses can
 * be searched for by their CRN and printed to a list.
 * 
 * @author Alejandro Lazo
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class CourseDBManager implements CourseDBManagerInterface{
	
	CourseDBStructure structure;

	public CourseDBManager() {
		structure = new CourseDBStructure(20);
	}
	
	/**
	 * Adds a course element to the database by adding it to the structure.
	 * @param id ID of the course
	 * @param crn The CRN of the course
	 * @param credits Amount of credits for class
	 * @param roomNum Location of class
	 * @param instructor Instructor of class
	 */
	public void add(String id, int crn, int credits, String roomNum, String instructor) {
		CourseDBElement ele = new CourseDBElement(id, crn, credits, roomNum, instructor);
		structure.add(ele);
		
	}

	/**
	 * Searches through the database to find the course associated with
	 * the CRN. Uses the structure to search.
	 * @param crn The CRN being searched for
	 * @return The course associated with CRN
	 */
	public CourseDBElement get(int crn){
		CourseDBElement ret = null;
		try {
			ret = structure.get(crn);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return ret;
	}

	/**
	 * Reads from a file and plugs in the data in to the database.
	 * @param input The file being read
	 */
	public void readFile(File input) throws FileNotFoundException{
		Scanner file = new Scanner(input);
		String line = "";
		String cID, rm, instr = "";
		int crn, crd;
		while(file.hasNextLine()) {
			line = file.nextLine();
			String[] arr = line.split(" ");
			cID = arr[0];
			crn = Integer.parseInt(arr[1]);
			crd = Integer.parseInt(arr[2]);
			rm = arr[3];
			for(int i=4; i<arr.length; i++) {
				if(i!=arr.length-1)
					instr += arr[i]+" ";
				else
					instr += arr[i];
			}
			structure.add(new CourseDBElement(cID, crn, crd, rm, instr));
			instr = "";
		}

		file.close();
	}

	/**
	 * Creates a list of all courses in the database, sorting by CRN
	 * @return ArrayList of all the courses' toStrings
	 */
	public ArrayList<String> showAll() {
		ArrayList<String> str = new ArrayList<String>();
		ArrayList<CourseDBElement> eles = new ArrayList<CourseDBElement>();
		for(int i=0; i<structure.getTableSize(); i++) {
			if(structure.hashTable[i] != null) {
				for(int j=0; j<structure.hashTable[i].size(); j++) {
					eles.add(structure.hashTable[i].get(j));
				}
			}
		}
		Collections.sort(eles);
		for(int x=0; x<eles.size(); x++) {
			str.add(eles.get(x).toString());
		}
		
		return str;
	}

}
