/**
 * CourseDBElement creates an Object based on the information for a
 * given course. It compares courses by their CRN.
 * 
 * @author Alejandro Lazo
 */
public class CourseDBElement implements java.lang.Comparable<CourseDBElement>{

	String courseID;
	int CRN;
	int credits;
	String room;
	String instructor;
	
	public CourseDBElement() {
		courseID = "";
		CRN = 0;
		credits = 0;
		room = "";
		instructor = "";
	}
	public CourseDBElement(String cID, int crn, int crd, String rm, String instr) {
		courseID = cID;
		CRN = crn;
		credits = crd;
		room = rm;
		instructor = instr;
	}
	public int getCRN() {
		return CRN;
	}
	public void setCRN(int crn) {
		CRN = crn;
	}
	
	@Override
	public int compareTo(CourseDBElement element) {
		if(this.CRN > element.CRN)
			return 0;
		else if(this.CRN > element.CRN)
			return 1;
		else
			return -1;
	}
	/**
	 * Creates a hashCode based on conversion of CRN to String
	 * @return the key associated with CRN
	 */
	public int hashCode() {
		String CRNstr = Integer.toString(this.CRN);
		return CRNstr.hashCode();
	}
	
	public String toString() {
		return "\nCourse:"+courseID+" CRN:"+CRN+" Credits:"+credits+" Instructor:"+instructor+" Room:"+room;
	}

}
