

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CourseDBManager_STUDENT_Test {
	private CourseDBManagerInterface stuMgr = new CourseDBManager();


	@Before
	public void setUp() throws Exception {
		stuMgr = new CourseDBManager();
	}


	@After
	public void tearDown() throws Exception {
		stuMgr = null;
	}


	@Test
	public void testAddToDB() {
		try {
			stuMgr.add("COMM108",24336,3,"HB150","John Man");
		}
		catch(Exception e) {
			fail("This should not have caused an Exception");
		}
	}
	

	@Test
	public void testShowAll() {
		stuMgr.add("MATH182",25547,4,"SC310","Stacey Jones");
		stuMgr.add("MATH284",25546,4,"SC314","Bob Builder");
		stuMgr.add("ENGL102",20439,3,"SC240","Joe Oden");
		ArrayList<String> list = stuMgr.showAll();
		
		assertEquals(list.get(2),"\nCourse:MATH182 CRN:25547 Credits:4 Instructor:Stacey Jones Room:SC310");
		assertEquals(list.get(1),"\nCourse:MATH284 CRN:25546 Credits:4 Instructor:Bob Builder Room:SC314");
		assertEquals(list.get(0),"\nCourse:ENGL102 CRN:20439 Credits:3 Instructor:Joe Oden Room:SC240");
		}

	@Test
	public void testRead() {
		try {
			File inputFile = new File("Test1.txt");
			PrintWriter inFile = new PrintWriter(inputFile);
			inFile.println("MATH182 25547 4 SC310 Stacey Jones");
			inFile.print("ENGL102 20439 3 SC240 Joe Oden");
			
			inFile.close();
			stuMgr.readFile(inputFile);
		} catch (Exception e) {
			fail("Should not have thrown an exception");
		}
	}
}