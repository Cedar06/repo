/**
 * CourseDBStructure creates a structure that can be used to create a
 * database for courses. The structure is made given a certain size and
 * uses the bucket structure to add and get data.
 * 
 * @author Alejandro Lazo
 */
import java.io.IOException;
import java.util.LinkedList;

public class CourseDBStructure implements CourseDBStructureInterface{

	LinkedList<CourseDBElement>[] hashTable;
	
	/**
	 * Creates structure, initializing hashTable to value of size
	 * @param size Sets size for hashTable
	 */
	public CourseDBStructure(int size) {
		hashTable = (LinkedList<CourseDBElement>[])new LinkedList[size];
	}
	/**
	 * Creates structure, initializing hashTable to value of size. Also
	 * takes in a String for testing purposes.
	 * @param str Used for testing purposes
	 * @param size Sets size for hashTable
	 */
	public CourseDBStructure(String str, int size) {
		hashTable = (LinkedList<CourseDBElement>[])new LinkedList[size];
	}
	/** 
	* Use the hashcode of the CourseDatabaseElement to see if it is 
	* in the hashtable.
	* 
	* If the CourseDatabaseElement does not exist in the hashtable,
	* add it to the hashtable.
	* 
	* @param element the CDE to be added
	*/
	public void add(CourseDBElement element) {
		int key = element.hashCode()%hashTable.length;
		boolean found = false;
		if(hashTable[key] == null) {
			hashTable[key] = new LinkedList<CourseDBElement>();
			hashTable[key].add(element);
		}else {
			for(int i=0;i<hashTable[key].size();i++) {
				if(hashTable[key].get(i).compareTo(element) == 0)
					found = true;
			}
			if(found == false)
				hashTable[key].addFirst(element);
		}
	}
	/** 
	* Use the hashcode of the CourseDatabaseElement to see if it is 
	* in the hashtable.
	* 
	* If the CourseDatabaseElement is in the hashtable, return it
	* If not, throw an IOException
	* 
	* @param element the CDE to be added
	 * @throws IOException 
	*/
	public CourseDBElement get(int crn) throws IOException {
		CourseDBElement ret = null;
		String crnStr = Integer.toString(crn);
		int key = crnStr.hashCode()%this.getTableSize();
		for(int i=0;i<hashTable[key].size();i++) {
			if(hashTable[key].get(i).getCRN() == crn)
				ret = hashTable[key].get(i);
		}
		if(ret == null)
			throw new IOException();
		
		return ret;
	}
	/**
	* Returns the size of the ConcordanceDataStructure (number of indexes in the array)
	*/
	public int getTableSize() {
		return hashTable.length;
	}

}
