import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Comparator;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


class SortedDoubleLinkedListSTUDENT_Test {
	SortedDoubleLinkedList<String> list;
	StringComparator comparator;

	@BeforeEach
	void setUp() throws Exception {
		comparator = new StringComparator();
		list = new SortedDoubleLinkedList<String>(comparator);
		list.add("Ale");
	}

	@AfterEach
	void tearDown() throws Exception {
		list = null;
	}

	@Test
	void testAdd() {
		assertEquals("Ale", list.getLast());
		list.add("Lazo");
		assertEquals("Lazo", list.getLast());
		list.add("Julian");
		assertEquals("Lazo", list.getLast());
		list.add("AAA");
		assertEquals("AAA", list.getFirst());
		
	}

	@Test
	void testAddToEnd() {
		try{
			list.addToEnd("Lazo");
			assertTrue("Did not throw a UnsupportedOperationException",false);
		}
		catch (UnsupportedOperationException e)
		{
			assertTrue("Successfully threw a UnsupportedOperationException",true);
		}
		catch (Exception e)
		{
			assertTrue("Threw an exception other than the UnsupportedOperationException", false);
		}
	}

	@Test
	void testAddToFront() {
		try{
			list.addToFront("Julian");
			assertTrue("Did not throw a UnsupportedOperationException",false);
		}
		catch (UnsupportedOperationException e)
		{
			assertTrue("Successfully threw a UnsupportedOperationException",true);
		}
		catch (Exception e)
		{
			assertTrue("Threw an exception other than the UnsupportedOperationException", false);
		}
	}

	private class StringComparator implements Comparator<String>
	{

		@Override
		public int compare(String arg0, String arg1) {
			// TODO Auto-generated method stub
			return arg0.compareTo(arg1);
		}
		
	}
}
