/**
 * BasicDoubleLinkedList is a class used to create a Doubly Linked List
 * structure, allowing for forward and backwards traversal. It also
 * includes an iterator class that can traverse the data as well
 * 
 * Author: Alejandro Lazo
 */
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class BasicDoubleLinkedList<T> implements Iterable<T>{

	protected int size;
	protected Node head;
	protected Node tail;
	
	public BasicDoubleLinkedList(){
		size = 0;
		head = null;
		tail = null;
	}
	
	/**
	 * adds the inputed data to the end of the list
	 * @param data The data being inserted
	 * @return the BasicDoubleLinkedList with new insertion
	 */
	public BasicDoubleLinkedList<T> addToEnd(T data){
		if(size == 0) {
			tail = new Node(null, data, null);
			head = tail;
			size++;
		}else {
			Node insert = new Node(tail, data, null);
			tail.next = insert;
			tail = insert;
			size++;
		}
		return this;
	}
	/**
	 * adds the inputed data to the front of the list
	 * @param data The data being inserted
	 * @return the BasicDoubleLinkedList with new insertion
	 */
	public BasicDoubleLinkedList<T> addToFront(T data){
		if(size == 0) {
			head = new Node(null, data, null);
			tail = head;
			size++;
		}else {
			Node insert = new Node(null, data, head);
			head.previous = insert;
			head = insert;
			size++;
		}
		return this;
	}
	/**
	 * Retrieves the data from the front of the list
	 * @return front Node's data
	 */
	public T getFirst() {
		return head.data;
	}
	/**
	 * Retrieves the data from the back of the list
	 * @return back Node's data
	 */
	public T getLast() {
		return tail.data;
	}
	/**
	 * Retrieves the amount of elements in the list
	 * @return size of list
	 */
	public int getSize() {
		return size;
	}

	/**
	 * Creates a new iterator for the data structure and returns it
	 * @return a new BasicDoubleLinkedListIterator
	 */
	public ListIterator<T> iterator() throws NoSuchElementException, UnsupportedOperationException{
		return new BasicDoubleLinkedListIterator();
	}
	
	/**
	 * Traverses through the list until the data entered matches a data in the
	 * list, then removes it by adjusting the Node's around it in the list
	 * @param data The data to be removed
	 * @param comparator The comparator used to compare the given data with data
	 * in the list
	 * @return The list with the Node removed
	 */
	public BasicDoubleLinkedList<T> remove(T data, Comparator<T> comparator){
		Node traverse = head;
		while(traverse != null) {
			if(comparator.compare(traverse.data, data) == 0) {
				if(traverse.previous != null)
					(traverse.previous).next = traverse.next;
				else
					head = traverse.next;
				if(traverse.next != null)
					(traverse.next).previous = traverse.previous;
				else
					tail = traverse.previous;
				traverse = null;
			}else
				traverse = traverse.next;
		}
		size--;
		return this;
	}
	/**
	 * Retrieves the first element in the list and removes it
	 * @return data in first element
	 */
	public T retrieveFirstElement() {
		T data;
		data = head.data;
		head = head.next;
		head.previous = null;
		return data;
	}
	/**
	 * Retrieves the last element in the list and removes it
	 * @return data in the last element
	 */
	public T retrieveLastElement() {
		T data;
		data = tail.data;
		tail = tail.previous;
		tail.next = null;
		return data;
	}
	/**
	 * Traverses through the list and adds each data into an ArrayList of
	 * that data type
	 * @return ArrayList with all data from list
	 */
	public ArrayList<T> toArrayList(){
		ArrayList<T> aList = new ArrayList<T>();
		Node traverse = head;
		while(traverse != null) {
			aList.add(traverse.data);
			traverse = traverse.next;
		}
		return aList;
	}
	
	protected class Node{
		protected T data;
		protected Node next;
		protected Node previous;
		
		public Node(Node prev, T data, Node next) {
			this.data = data;
			this.next = next;
			this.previous = prev;
		}
	}
	protected class BasicDoubleLinkedListIterator implements ListIterator<T>{
		
		protected Node nextNode;
		
		protected BasicDoubleLinkedListIterator() {
			nextNode = head;
		}

		/**
		 * Checks if iterator has more data
		 * @return if nextNode's data exists
		 */
		public boolean hasNext() {
			return nextNode.data != null;
		}

		/**
		 * Gets the data of the next element in the iterator and
		 * returns it
		 * @return the data next in line in the iterator
		 */
		public T next() {
			T data;
			if(hasNext()) {
				data = nextNode.data;
				if(nextNode.next!=null)
					nextNode = nextNode.next;
				else {
					nextNode = new Node(nextNode, null, null);
				}
			}
			else
				throw new NoSuchElementException();
			return data;
		}
		/**
		 * Checks if iterator has data previous to current Node
		 * @return if a Node exists previous to current Node
		 */
		public boolean hasPrevious() {
			return nextNode.previous != null;
		}
		/**
		 * Gets the data of the last element in the iterator and
		 * returns it
		 * @return the previous data in the iterator
		 */
		public T previous() {
			T data;
			if(hasPrevious()) {
				data = (nextNode.previous).data;
				nextNode = nextNode.previous;
			}else
				throw new NoSuchElementException();
			return data;
		}

		public int nextIndex() {
			throw new UnsupportedOperationException();
		}

		public int previousIndex() {
			throw new UnsupportedOperationException();
		}

		public void remove() {
			throw new UnsupportedOperationException();
		}

		public void set(T e) {
			throw new UnsupportedOperationException();
		}

		public void add(T e) {
			throw new UnsupportedOperationException();
		}
		
	}
}
