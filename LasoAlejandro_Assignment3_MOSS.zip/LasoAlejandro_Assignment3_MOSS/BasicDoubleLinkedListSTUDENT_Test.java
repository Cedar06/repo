import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Comparator;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


class BasicDoubleLinkedListSTUDENT_Test {
	BasicDoubleLinkedList<String> list;
	StringComparator comparator;

	@BeforeEach
	void setUp() throws Exception {
		comparator = new StringComparator();
		list = new BasicDoubleLinkedList<String>();
		list.addToEnd("Ale");
	}

	@AfterEach
	void tearDown() throws Exception {
		list = null;
	}

	@Test
	void testAddToEnd() {
		assertEquals("Ale", list.getLast());
		list.addToEnd("J");
		assertEquals("J", list.getLast());
		list.addToEnd("Lazo");
		assertEquals("Lazo", list.getLast());
	}

	@Test
	void testAddToFront() {
		assertEquals("Ale", list.getFirst());
		list.addToFront("Student: ");
		assertEquals("Student: ", list.getFirst());
		list.addToFront("MC: ");
		assertEquals("MC: ", list.getFirst());
	}

	@Test
	void testRemove() {
		list.addToFront("Hello");
		list.remove("Ale", comparator);
		assertEquals("Hello", list.getLast());
	}
	
	private class StringComparator implements Comparator<String>
	{

		@Override
		public int compare(String arg0, String arg1) {
			// TODO Auto-generated method stub
			return arg0.compareTo(arg1);
		}
		
	}
}
