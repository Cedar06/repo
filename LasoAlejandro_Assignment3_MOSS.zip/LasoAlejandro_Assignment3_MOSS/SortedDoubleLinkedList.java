/**
 * SortedDoubleLinkedList is a class used to create a Doubly Linked List
 * structure that has to remain sorted, allowing for forward and backwards
 * traversal.
 * 
 * Author: Alejandro Lazo
 */
import java.util.Comparator;
import java.util.ListIterator;

import BasicDoubleLinkedList.Node;

public class SortedDoubleLinkedList<T> extends BasicDoubleLinkedList<T> {
	
	protected Comparator<T> comparator;
	
	public SortedDoubleLinkedList(Comparator<T> comp) {
		super();
		comparator = comp;

	}
	/**
	 * Adds the specified data to the sorted list in order using the given
	 * comparator to see where the data belongs
	 * @param data The data being inserted in order
	 * @return The list following the addition
	 */
	public SortedDoubleLinkedList<T> add(T data){
		Node insert = new Node(null, data, null);
		if(size == 0) {
			tail = insert;
			head = insert;
			size++;
		}else {
			Node traverse = head;
			
			if(comparator.compare(insert.data, traverse.data) < 0) {
				insert.next = head;
				head.previous = insert;
				head = insert;
			}else {
				while(traverse != null) {
					if((comparator.compare(insert.data, traverse.data) < 0) || 
							traverse.next == null) {
						if(comparator.compare(insert.data, traverse.data) < 0) {
							insert.next = traverse;
							insert.previous = traverse.previous;
							(traverse.previous).next = insert;
							traverse.previous = insert;
						}else {
							insert.next = traverse.next;
							insert.previous = traverse;
							traverse.next = insert;
							tail = insert;
						}
						traverse = null;
					}else
						traverse = traverse.next;
				}
			}
			size++;
		}
		return this;
		
	}
	public SortedDoubleLinkedList<T> addToEnd(T data) throws UnsupportedOperationException{
		throw new UnsupportedOperationException("Invalid operation for sorted list");
		
	}
	public SortedDoubleLinkedList<T> addToFront(T data){
		throw new UnsupportedOperationException("Invalid operation for sorted list");
		
	}
	public ListIterator<T> iterator(){
		return super.iterator();
	}
	public SortedDoubleLinkedList<T> remove(T data, Comparator<T> comparator){
		super.remove(data, comparator);
		return this;
		
	}
}
