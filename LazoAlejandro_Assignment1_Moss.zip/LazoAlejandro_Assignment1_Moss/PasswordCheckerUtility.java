/* 	PasswordCheckerUtility is a utility class used to determine the validity of a password.
 *  If a password is found to have an error, it will throw the respective error in the order
 *  of importance. It also determines if a valid password is considered weak
 * 
 	Author: Alejandro Lazo
*/

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class PasswordCheckerUtility{
	
	/**
	 * Determines if password has any errors in order of importance or if it is valid. 
	 * @param pass The password string to be validated
	 * @return true if valid password, false otherwise
	 * @throws LengthException thrown if pass is not at least 6 chars.
	 * @throws NoDigitException thrown if there is no digit in pass
	 * @throws NoLowerAlphaException thrown if there is no lower-case char in pass
	 * @throws NoUpperAlphaException thrown if there is no upper-case char in pass
	 * @throws NoSpecialCharacterException thrown if there is no special char in pass
	 * @throws InvalidSequenceException thrown if there is a sequence of 3 identical chars in pass
	 */
	public static boolean isValidPassword(String pass) throws LengthException, 
	NoDigitException, NoLowerAlphaException, NoUpperAlphaException, NoSpecialCharacterException,
	InvalidSequenceException {
		boolean stillValid = true;
		if(!isValidLength(pass)&&stillValid)
			stillValid=false;
		if(!hasUpperAlpha(pass)&&stillValid)
			stillValid=false;
		if(!hasLowerAlpha(pass)&&stillValid)
			stillValid=false;
		if(!hasDigit(pass)&&stillValid)
			stillValid=false;
		if(!hasSpecialChar(pass)&&stillValid)
			stillValid=false;
		if(!hasSameCharInSequence(pass)&&stillValid)
			stillValid=false;
			
		return stillValid;
	}
	
	/**
	 * Determines if a valid password and has between 6 and 9 characters (is weak)
	 * @param pass String being checked if it is weak
	 * @return true if pass found to be weak, false otherwise
	 * @throws WeakPasswordException thrown if pass found to be weak
	 */
	public static boolean isWeakPassword(String pass) throws WeakPasswordException {
		
		try {
			if(isValidPassword(pass)&&hasBetweenSixAndNineChars(pass)) {
				throw new WeakPasswordException();
			}else
				return false;
		}catch(WeakPasswordException e) {
			return true;
		}catch(Exception e) {
			return false;
		}
	}
	
	/**
	 * Gets a list of passwords and goes through each, determining if the passwords are valid
	 * and if not, what error they are getting. The passwords with errors are added to a list and
	 * returned.
	 * @param passwords list of passwords to be checked
	 * @return the list of invalid passwords and their appropriate error message
	 */
	public static ArrayList<String> getInvalidPasswords(ArrayList<String> passwords) {
		ArrayList<String> invalids = new ArrayList<String>();
			for(int i=0;i<passwords.size();i++) {
				try {
					isValidPassword(passwords.get(i));
				}catch(Exception e) {
					invalids.add(passwords.get(i) + " -> " + e.getMessage());
				}
			}
			return invalids;
	}
	
	/**
	 * Compares two passwords and make sure their lengths and content are the same
	 * @param p1 Original password
	 * @param p2 Password being checked if it matches p1
	 * @throws UnmatchedException thrown if not equal in either aspect.
	 */
	public static void comparePasswords(String p1, String p2) throws UnmatchedException{
		if((p1.length()!=p2.length())||!(p1.equals(p2)))
			throw new UnmatchedException();

	}
	
	/**
	 * Compares two passwords and returns true if their lengths and content are the same
	 * false otherwise
	 * @param p1 Original password
	 * @param p2 Password being checked if it matches p1
	 * @return returns false if password either not same length or same content, true otherwise
	 */
	public static boolean comparePasswordsWithReturn(String p1, String p2){
		if((p1.length()!=p2.length())||!(p1.equals(p2)))
			return false;
		else
			return true;

	}
	
	/**
	 * Checks if the password is at least 6 characters long
	 * @param pass Password being checked
	 * @return true if pass is at least 6 char
	 * @throws LengthException thrown if pass found to be less than 6 char
	 */
	public static boolean isValidLength(String pass) throws LengthException {

		if(pass.length()<6) {
			throw new LengthException();
		}else
			return true;

	}
	
	/**
	 * Checks if the pass string contains a digit
	 * @param pass Password being checked
	 * @return true if pass contains a digit
	 * @throws NoDigitException thrown if no digit was found in pass
	 */
	public static boolean hasDigit(String pass) throws NoDigitException{
		
			for(int i = 0;i<pass.length();i++) {
				if(pass.charAt(i)>=48&&pass.charAt(i)<=57)
					return true;
			}
			throw new NoDigitException();

	}
	
	/**
	 * Checks if the pass contains a lowercase char
	 * @param pass Password being checked
	 * @return true if found to contain a lowercase char
	 * @throws NoLowerAlphaException thrown if no lowercase char was found in pass
	 */
	public static boolean hasLowerAlpha(String pass) throws NoLowerAlphaException{

		for(int i = 0;i<pass.length();i++) {
			if(pass.charAt(i)>=97&&pass.charAt(i)<=122)
			{
				return true;
			}
		}
		throw new NoLowerAlphaException();

	}
	
	/**
	 * Checks if the pass contains a uppercase char
	 * @param pass Password being checked
	 * @return true if found to contain a uppercase char
	 * @throws NoUpperAlphaException thrown if no uppercase char was found in pass
	 */
	public static boolean hasUpperAlpha(String pass) throws NoUpperAlphaException{

		for(int i = 0;i<pass.length();i++) {
			if(pass.charAt(i)>=65&&pass.charAt(i)<=90)
				return true;
		}
		throw new NoUpperAlphaException();

	}
	
	/**
	 * Checks if the pass contains a special character
	 * @param pass Password being checked
	 * @return true if a special character was found
	 * @throws NoSpecialCharacterException thrown if no special character was found in pass
	 */
	public static boolean hasSpecialChar(String pass) throws NoSpecialCharacterException{
		Pattern pattern = Pattern.compile("[a-zA-Z0-9]*");
		Matcher matcher = pattern.matcher(pass);
		if(matcher.matches())
			throw new NoSpecialCharacterException();
		else
			return true;


	}
	
	/**
	 * Checks a String pass to see if it has between 6 and 9 characters
	 * @param pass Password being checked
	 * @return true if pass found to have between 6 and 9 char, false otherwise
	 */
	public static boolean hasBetweenSixAndNineChars(String pass) {
		if(pass.length()>5 && pass.length()<10)
			return true;
		else
			return false;
	}
	
	/**
	 * Checks if the pass has a sequence of 3 of the same char in a row
	 * @param pass Password being checked
	 * @return true if no sequence of 3 identical chars found
	 * @throws InvalidSequenceException thrown if sequence of 3 or more identical chars found
	 */
	public static boolean hasSameCharInSequence(String pass) throws InvalidSequenceException{

		char first = 0, second = 0, third = 0;
		for(int i=0;i<pass.length();i++) {
			if(i==0)
				first = pass.charAt(i);
			if(i==1)
				second = pass.charAt(i);
			if(i==2)
				third = pass.charAt(i);
			if(i>2) {
				first = second;
				second = third;
				third = pass.charAt(i);
			}
			if(first == second && first == third)
				throw new InvalidSequenceException();
		}
		return true;

	}
}

