
public class UnmatchedException extends Exception{
	public UnmatchedException() {
		super("Passwords do not match");
	}
	public UnmatchedException(String err) {
		super(err);
	}

}
