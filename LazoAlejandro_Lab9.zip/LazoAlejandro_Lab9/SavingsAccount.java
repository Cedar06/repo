public class SavingsAccount extends BankAccount{
	private static double RATE = .025;
	protected static int savingsNumber = 0;
	private String accountNumber;
	
	public SavingsAccount(String name, double initial) {
		super(name,initial);
		accountNumber = super.getAccountNumber()+"-"+savingsNumber;
		savingsNumber++;
	}
	public SavingsAccount(SavingsAccount acc, double initial) {
		super(acc,initial);
		accountNumber = super.getAccountNumber()+"-"+savingsNumber;
		savingsNumber++;
	}
	public void postInterest() {
		setBalance(getBalance()*(1+(RATE/12)));
	}
	public String getAccountNumber()
	{
		return accountNumber;
	}
}