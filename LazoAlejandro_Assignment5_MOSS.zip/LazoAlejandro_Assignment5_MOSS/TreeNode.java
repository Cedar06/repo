/**
 * TreeNode is a generic class used to create
 * a Binary Tree structure for holding data with
 * 2 related children.
 * 
 * @author Alejandro Lazo
 */
public class TreeNode<T> {
	T data;
	TreeNode<T> left;
	TreeNode<T> right;
	public TreeNode(T dataNode) {
		data = dataNode;
		left = null;
		right = null;
	}
	public TreeNode(TreeNode<T> node) {
		data = node.getData();
		left = null;
		right = null;
	}
	/**
	 * Retrieves the data from the node
	 * @return value in data
	 */
	public T getData() {
		return data;
	}
}
