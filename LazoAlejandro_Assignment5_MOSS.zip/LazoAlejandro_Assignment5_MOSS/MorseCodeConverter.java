import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
/**
 * MorseCodeConverter uses the MorseCodeTree class to convert a 
 * String message from MorseCode to English. It can also print
 * the tree structure used for its MorseCode, and use input data
 * from a file to be translated.
 * 
 * @author Alejandro Lazo
 */
public class MorseCodeConverter {

	static MorseCodeTree<String> tree = new MorseCodeTree<String>();
	
	/**
	 * Uses the MorseCodeTree tree to output the order of the
	 * data using the InOrder traversal.
	 * @return String of data from inOrder traversal
	 */
	public static String printTree() {
		String print = "";
		ArrayList<String> list = tree.toArrayList();
		for(int i=0;i<list.size();i++) {
			if(i!=list.size()-1)
				print += (list.get(i) + " ");
			else
				print += (list.get(i));
		}
		return print;
	}
	/**
	 * Converts a string of dots, dashes, spaces, and slashes
	 * into English using the tree's structure to find what
	 * code corresponds to what letter.  
	 * @param code MorseCode being translated
	 * @return English translation of MorseCode
	 */
	public static String convertToEnglish(String code) {
		String line = "";
		String[] data = code.split(" ");
		for(int i=0;i<data.length;i++) {
			if(data[i].equals("/"))
				line+=" ";
			else
				line += tree.fetch(data[i]);
		}
        return line;
	}
	/**
	 * Converts a string of dots, dashes, spaces, and slashes
	 * inputed from a file into English using the tree's
	 * structure to find what code corresponds to what letter. 
	 * @param codeFile File where MorseCode is
	 * @return English translation of MorseCode from file
	 * @throws FileNotFoundException No file was found
	 */
	public static String convertToEnglish(File codeFile) throws FileNotFoundException{
		Scanner file = new Scanner(codeFile);
		String line = "";
		String english = "";
		while(file.hasNextLine()) {
			line = file.nextLine();
			english += convertToEnglish(line);
		}
		file.close();
		return english;
	}
}
