import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MorseCodeTreeTest {

	MorseCodeTree<String> tree;
	
	@BeforeEach
	void setUp() throws Exception {
		tree = new MorseCodeTree<String>();
	}

	@AfterEach
	void tearDown() throws Exception {
		tree = null;
	}

	@Test
	void testSetRoot() {
		TreeNode<String> newRoot = new TreeNode<String>("root");
		tree.setRoot(newRoot);
		assertEquals("root", tree.getRoot().getData());
	}

	@Test
	void testInsert() {
		TreeNode<String> newRoot = new TreeNode<String>("root");
		tree.setRoot(newRoot);
		assertEquals("root", tree.getRoot().getData());
		tree.insert(".", "b");
		assertEquals("b", tree.getRoot().left.getData());
		tree.insert("..", "a");
		assertEquals("a", tree.getRoot().left.left.getData());
		tree.insert(".-", "c");
		assertEquals("c", tree.getRoot().left.right.getData());
	}

	@Test
	void testFetch() {
		TreeNode<String> newRoot = new TreeNode<String>("root");
		tree.setRoot(newRoot);
		assertEquals("root", tree.getRoot().getData());
		tree.insert(".", "z");
		assertEquals("z", tree.fetch("."));
		tree.insert("..", "y");
		assertEquals("y", tree.fetch(".."));
		tree.insert("...", "x");
		assertEquals("x", tree.fetch("..."));
	}

	@Test
	void testDelete() {
		try {
			tree.delete("root");
			assertTrue("This should have caused an UnsupportedOperationException", false);
		}
		catch (UnsupportedOperationException e){
			assertTrue("This should have caused an UnsupportedOperationException", true);
		}
		catch (Exception e){
			assertTrue("This should have caused an UnsupportedOperationException", false);
		}
	}

	@Test
	void testUpdate() {
		try {
			tree.update();
			assertTrue("This should have caused an UnsupportedOperationException", false);
		}
		catch (UnsupportedOperationException e){
			assertTrue("This should have caused an UnsupportedOperationException", true);
		}
		catch (Exception e){
			assertTrue("This should have caused an UnsupportedOperationException", false);
		}
	}

	@Test
	void testBuildTree() {
		//An example from each level
		assertEquals("t", tree.fetch("-"));
		assertEquals("a", tree.fetch(".-"));
		assertEquals("k", tree.fetch("-.-"));
		//two from level 4
		assertEquals("l", tree.fetch(".-.."));
		assertEquals("q", tree.fetch("--.-"));
	}

	@Test
	void testToArrayList() {
		ArrayList<String> correct = new ArrayList<>(Arrays.asList("h","s","v","i","f",
				"u","e","l","r","a","p","w","j","","b","d","x","n","c","k","y","t","z",
				"g","q","m","o"));
		ArrayList<String> list = tree.toArrayList();
		assertEquals(correct, list);
	}

}
