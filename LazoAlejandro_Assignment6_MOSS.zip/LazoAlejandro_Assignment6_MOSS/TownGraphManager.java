import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
/**
 * TownGraphManager uses a Graph object to create a web of Towns and Roads. This
 * can be used to create graphs from a file, add or delete roads and towns, and
 * find the shortest path from a specified source and destination Town given the
 * names of the Towns.
 * 
 * @author Alejandro Lazo
 *
 */
public class TownGraphManager implements TownGraphManagerInterface{

	public Graph graph;
	
	public TownGraphManager() {
		graph = new Graph();
	}
	/**
	 * Uses graphs populateTownGraph to create a graph given a file with Towns, distances, and Road names.
	 * @param fileName name of the File to be used
	 * @throws FileNotFoundException File cannot be found
	 * @throws IOException File cannot be read
	 */
	public void populateTownGraph(File fileName) throws FileNotFoundException, IOException {
		graph.populateTownGraph(fileName);
	}
	@Override
	public boolean addRoad(String town1, String town2, int weight, String roadName) {
		if(!graph.containsVertex(graph.getVertex(town1)) || !graph.containsVertex(graph.getVertex(town2)))
			return false;
		else {
			graph.addEdge(graph.getVertex(town1), graph.getVertex(town2), weight, roadName);
			return true;
		}
	}

	@Override
	public String getRoad(String town1, String town2) {
		Road r = graph.getEdge(graph.getVertex(town1), graph.getVertex(town2));
		return r.getName();
	}

	@Override
	public boolean addTown(String v) {
		Town t = new Town(v);
		return graph.addVertex(t);
	}

	@Override
	public Town getTown(String name) {
		Town t = graph.getVertex(name);
		return t;
	}

	@Override
	public boolean containsTown(String v) {
		Town t = graph.getVertex(v);
		if(t == null)
			return false;
		else
			return graph.containsVertex(t);
		
	}

	@Override
	public boolean containsRoadConnection(String town1, String town2) {
		if(!graph.containsVertex(graph.getVertex(town1)) || !graph.containsVertex(graph.getVertex(town2)))
			return false;
		else 
			return graph.containsEdge(graph.getVertex(town1), graph.getVertex(town2));
	}

	@Override
	public ArrayList<String> allRoads() {
		Set<Road> roads = graph.edgeSet();
		ArrayList<String> roadNames = new ArrayList<String>();
		for(Iterator<Road> r = roads.iterator(); r.hasNext();) {
			roadNames.add(r.next().getName());
		}
		Collections.sort(roadNames);
		return roadNames;
	}

	@Override
	public boolean deleteRoadConnection(String town1, String town2, String road) {
		if(containsRoadConnection(town1,town2)) {
			Road r = graph.getEdge(graph.getVertex(town1), graph.getVertex(town2));
			graph.removeEdge(r.getSource(),r.getDestination(),r.getWeight(),road);
			return true;
		}else
			return false;
	}

	@Override
	public boolean deleteTown(String v) {
		if(containsTown(v)) {
			return graph.removeVertex(graph.getVertex(v));
		}else
			return false;
	}

	@Override
	public ArrayList<String> allTowns() {
		Set<Town> towns = graph.vertexSet();
		ArrayList<String> townNames = new ArrayList<String>();
		for(Iterator<Town> t = towns.iterator(); t.hasNext();) {
			townNames.add(t.next().getName());
		}
		Collections.sort(townNames);
		return townNames;
	}

	@Override
	public ArrayList<String> getPath(String town1, String town2) {
		return graph.shortestPath(graph.getVertex(town1), graph.getVertex(town2));
	}
	
}