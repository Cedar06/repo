import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Road_STUDENT_Test {
	Road r1;
	Road r2;
	Town t1;
	Town t2;
	Town t3;
	Town t4;

	@BeforeEach
	void setUp() throws Exception {
		t1 = new Town("t1");
		t2 = new Town("t2");
		t3 = new Town("t3");
		t4 = new Town("t4");
		r1 = new Road(t1,t2,10,"Road1");
		r2 = new Road(t3,t4,4,"Road2");
	}

	@AfterEach
	void tearDown() throws Exception {
		r1=null;
		r2=null;
		t1=null;
		t2=null;
		t3=null;
		t4=null;
	}

	@Test
	void testContains() {
		assertTrue(r1.contains(t1));
		assertTrue(r2.contains(t4));
	}

	@Test
	void testGetWeight() {
		assertEquals(10,r1.getWeight());
		assertEquals(4,r2.getWeight());
	}

	@Test
	void testGetName() {
		assertEquals("Road1",r1.getName());
		assertEquals("Road2",r2.getName());
	}

	@Test
	void testGetDestination() {
		assertEquals(t1,r1.getDestination());
		assertEquals(t3,r2.getDestination());
	}

	@Test
	void testGetSource() {
		assertEquals(t2,r1.getSource());
		assertEquals(t4,r2.getSource());
	}

	@Test
	void testEqualsObject() {
		assertEquals(new Road(t1,t2,10,"Road1"),r1);
		assertEquals(new Road(t3,t4,4,"Road2"),r2);
	}

}
