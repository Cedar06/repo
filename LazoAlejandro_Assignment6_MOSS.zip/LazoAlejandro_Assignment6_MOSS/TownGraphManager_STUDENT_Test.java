import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TownGraphManager_STUDENT_Test {
	private TownGraphManagerInterface graph;
	private String[] town;

	@BeforeEach
	void setUp() throws Exception {
		graph = new TownGraphManager();
		  town = new String[5];
		  
		  for (int i = 1; i < 5; i++) {
			  town[i] = "Town_" + i;
			  graph.addTown(town[i]);
		  }
		  
		  graph.addRoad(town[1], town[2], 2, "Road_1");
		  graph.addRoad(town[1], town[3], 4, "Road_2");
		  graph.addRoad(town[2], town[3], 7, "Road_3");
		  graph.addRoad(town[2], town[4], 5, "Road_4");
		  graph.addRoad(town[4], town[1], 10, "Road_5");
	}

	@AfterEach
	void tearDown() throws Exception {
		graph = null;
	}

	@Test
	void testAddRoad() {
		ArrayList<String> roads = graph.allRoads();
		assertEquals("Road_4", roads.get(3));
		assertEquals("Road_5", roads.get(4));
		graph.addRoad(town[4], town[3], 1,"Road_6");
		roads = graph.allRoads();
		assertEquals("Road_4", roads.get(3));
		assertEquals("Road_5", roads.get(4));
		assertEquals("Road_6", roads.get(5));
	}

	@Test
	void testGetRoad() {
		assertEquals("Road_3", graph.getRoad(town[2], town[3]));
		assertEquals("Road_5", graph.getRoad(town[4], town[1]));
	}

	@Test
	void testAddTown() {
		assertEquals(false, graph.containsTown("Town_X"));
		graph.addTown("Town_X");
		assertEquals(true, graph.containsTown("Town_X"));
	}

	@Test
	void testGetTown() {
		assertEquals(new Town("Town_1"),graph.getTown(town[1]));
	}

	@Test
	void testContainsTown() {
		assertEquals(true, graph.containsTown("Town_2"));
		assertEquals(false, graph.containsTown("Town_6"));
	}

	@Test
	void testContainsRoadConnection() {
		assertEquals(true, graph.containsRoadConnection(town[2], town[3]));
		assertEquals(false, graph.containsRoadConnection(town[3], town[4]));
	}

	@Test
	void testGetPath() {
		ArrayList<String> path = graph.getPath(town[2],town[3]);
		assertNotNull(path);
		assertTrue(path.size() > 0);
		assertEquals("Town_2 via Road_1 to Town_1 2 mi",path.get(0).trim());
		assertEquals("Town_1 via Road_2 to Town_3 4 mi",path.get(1).trim());
	}

}
