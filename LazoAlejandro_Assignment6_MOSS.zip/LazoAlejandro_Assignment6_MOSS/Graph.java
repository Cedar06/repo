import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
/**
 * Implementation of a Graph Interface that creates a web of Towns and Roads.
 * Can also implement the graph based on a file and is used to find the
 * shortest distance between two Towns based on the weight of the Roads.
 * 
 * @author Alejandro Lazo
 *
 */
public class Graph implements GraphInterface<Town, Road>{

	Set<Town> towns;
	Set<Road> roads;
	int count;
	
	public Graph() {
		towns = new HashSet<Town>();
		roads = new HashSet<Road>();
		count = 0;
	}
	/**
	 * Creates a graph given a file with Towns, distances, and Road names.
	 * @param fileName name of the File to be used
	 * @throws FileNotFoundException File cannot be found
	 * @throws IOException File cannot be read
	 */
	public void populateTownGraph(File fileName) throws FileNotFoundException, IOException {
		Scanner file = new Scanner(fileName);
		String line = "";
		while(file.hasNextLine()) {
			line = file.nextLine();
			String[] arr = line.split(";");
			if(!containsVertex(getVertex(arr[1])))
				addVertex(new Town(arr[1]));
			if(!containsVertex(getVertex(arr[2])))
				addVertex(new Town(arr[2]));
			String[] arr2 = arr[0].split(",");
			addEdge(getVertex(arr[2]),getVertex(arr[1]),Integer.parseInt(arr2[1]),arr2[0]);
		}
		file.close();
	}
	@Override
	public Road getEdge(Town sourceVertex, Town destinationVertex) {
		if(containsEdge(sourceVertex, destinationVertex)){
			for(Iterator<Road> i = roads.iterator(); i.hasNext();) {
				Road currentRoad = i.next();
				if(currentRoad.contains(sourceVertex) && currentRoad.contains(destinationVertex))
					return currentRoad;
			}
			return null;
		}else
			return null;
	}

	@Override
	public Road addEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
		if(!(towns.contains(sourceVertex)) || !(towns.contains(destinationVertex)))
			throw new IllegalArgumentException();
		Road toAdd = new Road(sourceVertex, destinationVertex, weight, description);
		roads.add(toAdd);
		sourceVertex.addToList(destinationVertex);
		destinationVertex.addToList(sourceVertex);
		return toAdd;
	}

	@Override
	public boolean addVertex(Town v) {
		for(Iterator<Town> i = towns.iterator(); i.hasNext();) {
			if(v.equals(i.next()))
				return false;
		}
		towns.add(v);
		count++;
		return true;
		
	}
	/**
	 * Gets a vertex (Town) from the graph using the name of the String
	 * @param str The name of the town to be retrieved
	 * @return the Town found in graph, or null if not found
	 */
	public Town getVertex(String str) {
		for(Iterator<Town> i = towns.iterator(); i.hasNext();) {
			Town t = i.next();
			if(str.equals(t.getName()))
				return t;
		}
		return null;
	}

	@Override
	public boolean containsEdge(Town sourceVertex, Town destinationVertex) {
		if(!(towns.contains(sourceVertex)) || !(towns.contains(destinationVertex)))
			return false;
		for(Iterator<Road> i = roads.iterator(); i.hasNext();) {
			Road currentRoad = i.next();
			if(currentRoad.contains(sourceVertex) && currentRoad.contains(destinationVertex))
				return true;
		}
		return false;
	}

	@Override
	public boolean containsVertex(Town v) {
		if(v == null)
			return false;
		for(Iterator<Town> i = towns.iterator(); i.hasNext();) {
			if(v.equals(i.next()))
				return true;
		}
		return false;
	}

	@Override
	public Set<Road> edgeSet() {
		return roads;
	}

	@Override
	public Set<Road> edgesOf(Town vertex) {
		Set<Road> roadToV= new HashSet<Road>();
		if(!containsVertex(vertex))
			throw new IllegalArgumentException();
		if(vertex == null)
			throw new NullPointerException();
		for(Iterator<Road> i = roads.iterator(); i.hasNext();) {
			Road currentRoad = i.next();
			if(currentRoad.contains(vertex))
				roadToV.add(currentRoad);
		}
		return roadToV;
	}

	@Override
	public Road removeEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
		if(description != null || weight > -1) {
			for(Iterator<Road> i = roads.iterator(); i.hasNext();) {
				Road currentRoad = i.next();
				if(currentRoad.equals(new Road(sourceVertex, destinationVertex, weight, description))) {
					roads.remove(currentRoad);
					return currentRoad;
				}
			}
			return null;
		}else
			return null;
	}

	@Override
	public boolean removeVertex(Town v) {
		if(!containsVertex(v))
			return false;
		else {
			for(Iterator<Town> i = towns.iterator(); i.hasNext();) {
				Town currentTown = i.next();
				if(currentTown.equals(v)) {
					Set<Road> toRemove = edgesOf(currentTown);
					roads.removeAll(toRemove);
					towns.remove(currentTown);
					count--;
					return true;
				}
			}
			return false;
		}
	}

	@Override
	public Set<Town> vertexSet() {
		return towns;
	}

	@Override
	public ArrayList<String> shortestPath(Town sourceVertex, Town destinationVertex) {
		ArrayList<String> path = dijkstraShortestPath(sourceVertex, destinationVertex);
		return path;
	}

	/**
	 * dijkstraShortestPath algorithm. Used to find the shortest path from a specified
	 * vertex to all other vertices in the graph. Then uses a given destination Vertex
	 * to find the shortest path from source to destination. Prints the path into an
	 * ArrayList of Strings and returns it
	 * @param sourceVertex finds shortest path to all vertices from this vertex
	 * @param destinationVertex used to print shortest path from source to this vertex
	 * @return returns the ArrayList of Towns visited and Roads taken
	 */
	public ArrayList<String> dijkstraShortestPath(Town sourceVertex, Town destinationVertex) {
		
		//keep track of towns distances, previous towns, and if visited
		class Path{
			Town current;
			int dist;
			Town prevTown;
			boolean visited;
			public Path() {
				current = null;
				dist = 0;
				prevTown = null;
				visited = false;
			}
			public Path(Town s, int d) {
				current = s;
				dist = d;
				prevTown = null;
				visited = false;
			}
			public void setPrev(Town p) {
				prevTown = p;
			}
			public Town getPrev() {
				return prevTown;
			}
			public void setDist(int d) {
				dist = d;
			}
			public int getDist() {
				return dist;
			}
			public Town getCurrent() {
				return current;
			}
			public void setVisited(boolean v) {
				visited = v;
			}
			public boolean getVisited() {
				return visited;
			}
		}
		//current lowest distance town to check
		int current = 0;
		
		//fill paths with all available towns from the graph, set their distance to max
		Path[] paths = new Path[count];
		int x = 0;
		for(Iterator<Town> i = towns.iterator();i.hasNext();) {
			Town t = i.next();
			paths[x] = new Path(t, Integer.MAX_VALUE);
			x++;
		}
		
		//find and set index of current to the sourceVertex given, with distance of 0
		for(int j=0;j<paths.length;j++) {
			if(paths[j].getCurrent().equals(sourceVertex))
				current = j;
		}
		paths[current].setDist(0);
		
		//loop while there remain unvisited paths(towns)
		int visited = 0;
		while(visited<count) {
			//find all adjacent towns to current lowest distance path's town
			ArrayList<Town> adj = paths[current].getCurrent().getAdjTowns();
			for(int v = 0; v<adj.size();v++) {
				for(int j=0;j<paths.length;j++) {
					if(paths[j].getCurrent().equals(adj.get(v)) && !paths[j].getVisited()) {
						//if the total distance of the current town + the new path to the
						//unvisited town is less than whatever the distance that adjacent town
						//may already have, then change that unvisited towns previous town to
						//this current path's town and distance + new path weight.
						if((paths[current].getDist() + getEdge(paths[j].getCurrent(),
								paths[current].getCurrent()).getWeight()) < paths[j].getDist()) {
							paths[j].setPrev(paths[current].getCurrent());
							paths[j].setDist(paths[current].getDist() + getEdge(paths[j].getCurrent(),
									paths[current].getCurrent()).getWeight());
						}
					}
				}
			}
			//set the town being checked to visited
			paths[current].setVisited(true);
			visited++;
			
			//find the next lowest distance path from the sourceVertex that has not been visited
			//and set that to the current town to be checked
			int minDist = Integer.MAX_VALUE;
			for(int i=0; i<paths.length;i++) {
				if(!paths[i].getVisited()) {
					if(paths[i].getDist() < minDist) {
						current = i;
						minDist = paths[i].getDist();
					}
				}

			}
			
		}
		
		//loop through the destinationVertex's previous towns and their distances to create
		//an arrayList of all previous roads taken and towns visited
		ArrayList<String> list = new ArrayList<String>();
		for(int i=0;i<paths.length;i++) {
			if(paths[i].getCurrent().equals(destinationVertex)) {
				while(paths[i].getPrev() != null) {
					list.add(paths[i].getPrev().getName()+" via "+getEdge(paths[i].getCurrent(),
							paths[i].getPrev()).getName()+" to "+paths[i].getCurrent().getName()
							+" "+getEdge(paths[i].getCurrent(),paths[i].getPrev()).getWeight()+" mi");
					for(int j=0;j<paths.length;j++) {
						if(paths[j].getCurrent().equals(paths[i].getPrev())) {
							i = j;
							j = paths.length;
						}
					}
				}
				i = paths.length;
			}
		}
		//reverse the list to start from sourceVertex
		Collections.reverse(list);
		return list;
		
	}


	
}