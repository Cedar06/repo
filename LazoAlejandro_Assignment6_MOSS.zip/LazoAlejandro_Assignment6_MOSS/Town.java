import java.util.ArrayList;
import java.util.LinkedList;
/**
 * Town is a Node class that is used to create a graph
 * of Towns and Roads. It stores adjacent towns, or
 * towns that are connected via road.
 * 
 * @author Alejandro Lazo
 */
public class Town implements Comparable<Town>{
	String name;
	ArrayList<Town> towns;
	
	public Town(String name) {
		this.name = name;
		towns = new ArrayList<>();
	}
	/**
	 * Gets the name of the Town
	 * @return Town name
	 */
	public String getName() {
		return name;
	}
	/**
	 * Adds to the adjacent towns of Town
	 * @param town The town to be added to adjacent
	 */
	public void addToList(Town town) {
		towns.add(town);
	}
	/**
	 * Returns the adjacent towns of this Town
	 * @return list of Towns
	 */
	public ArrayList<Town> getAdjTowns(){
		return towns;
	}
	/**
	 * Compares this Town with another based on 
	 * their name and returns using Java's String
	 * compareTo()
	 * @return compareTo of town Strings
	 */
	public int compareTo(Town town) {
		return name.compareTo(town.getName());
	}
	/**
	 * returns the hashCode of the Town based on the
	 * name of the Town, using Java's String hashCode
	 * @return hashCode based off name String
	 */
	public int hashCode() {
		return name.hashCode();
	}
	/**
	 * Returns whether or not two Towns are equal based
	 * off of their names.
	 * @return true if same name, false otherwise
	 */
	public boolean equals(Object o) {
		Town t = (Town)o;
		if(this.name.equals(t.getName()))
			return true;
		else
			return false;
	}
	/**
	 * Returns name of the Town
	 * @return this name
	 */
	public String toString() {
		return name;
	}
	
}