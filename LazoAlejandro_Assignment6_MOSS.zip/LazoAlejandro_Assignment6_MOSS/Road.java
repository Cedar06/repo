
/**
 * Road is an Edge class used in a graph of Towns and Roads. It
 * connects two Town objects, assigns them a weight, and is 
 * labeled with a name.
 * 
 * @author Alejandro Lazo
 *
 */
public class Road implements Comparable<Road>{
	Town town1;
	Town town2;
	int distance;
	String name;
	
	public Road(Town t, Town t2, int dist, String name) {
		town1 = t;
		town2 = t2;
		distance = dist;
		this.name = name;
	}
	/**
	 * Returns whether or not this Road contains a specified town.
	 * @param town Town to be checked if present in Road
	 * @return true if Town is found, false otherwise
	 */
	public boolean contains(Town town) {
		if(town.equals(town1) || town.equals(town2))
			return true;
		else
			return false;
	}
	/**
	 * Gets the weight of the road
	 * @return this weight
	 */
	public int getWeight() {
		return distance;
	}
	/**
	 * Gets the name of the road
	 * @return this name
	 */
	public String getName() {
		return name;
	}
	/**
	 * Gets the destination Town of the Road
	 * @return this Road's destination Town
	 */
	public Town getDestination() {
		return town1;
	}
	/**
	 * Gets the source Town of the Road
	 * @return this Road's source Town
	 */
	public Town getSource() {
		return town2;
	}
	@Override
	public boolean equals(Object r) {
		Road road = (Road)r;
		if(this.contains(road.getDestination()) && this.contains(road.getSource()))
			return true;
		else
			return false;
	}
	/**
	 * Compares two Roads based on their weights
	 * @return comparison based on int of weights
	 */
	public int compareTo(Road r) {
		return Integer.compare(distance, r.getWeight());
	}
	/**
	 * Prints the name of the road and the towns it connects
	 * @return String with name and corresponding Towns
	 */
	public String toString() {
		return name+", Towns: "+town1.toString()+", "+town2.toString();
	}
	
	
}
