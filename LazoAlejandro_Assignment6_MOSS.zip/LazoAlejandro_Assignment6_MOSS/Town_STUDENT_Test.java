import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Town_STUDENT_Test {
	Town t1;
	Town t2;

	@BeforeEach
	void setUp() throws Exception {
		t1 = new Town("Potomac");
		t2 = new Town("Silver Spring");
	}

	@AfterEach
	void tearDown() throws Exception {
		t1 = null;
		t2 = null;
	}

	@Test
	void testGetName() {
		assertEquals("Potomac", t1.getName());
		assertEquals("Silver Spring", t2.getName());
	}

	@Test
	void testGetAdjTowns() {
		Graph g = new Graph();
		g.addVertex(t1);
		g.addVertex(t2);
		g.addEdge(t1,t2,0,"Road");
		ArrayList<Town> towns = new ArrayList<Town>();
		towns.add(t1);
		assertEquals(towns, t2.getAdjTowns());
	}

	@Test
	void testEqualsTown() {
		assertEquals(new Town("Potomac"), t1);
	}

}
