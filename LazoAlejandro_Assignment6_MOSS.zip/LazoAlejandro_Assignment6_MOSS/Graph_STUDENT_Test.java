import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Graph_STUDENT_Test {
	private Graph graph;
	private Town[] town;

	@BeforeEach
	void setUp() throws Exception {
		graph = new Graph();
		  town = new Town[5];
		  
		  for (int i = 1; i < 5; i++) {
			  town[i] = new Town("Town_" + i);
			  graph.addVertex(town[i]);
		  }
		  
		  graph.addEdge(town[1], town[2], 2, "Road_1");
		  graph.addEdge(town[1], town[3], 4, "Road_2");
		  graph.addEdge(town[2], town[3], 7, "Road_3");
		  graph.addEdge(town[2], town[4], 5, "Road_4");
		  //graph.addEdge(town[3], town[4], 5, "Road_5");
		  graph.addEdge(town[4], town[1], 10, "Road_6");
	}

	@AfterEach
	void tearDown() throws Exception {
		graph = null;
	}

	@Test
	void testGetEdge() {
		assertEquals(new Road(town[1], town[2], 1, "Road_1"), graph.getEdge(town[1], town[2]));
		assertEquals(new Road(town[2], town[3], 3, "Road_3"), graph.getEdge(town[2], town[3]));
	}

	@Test
	void testAddEdge() {
		Town t = new Town("town");
		graph.addVertex(t);
		assertEquals(false, graph.containsEdge(town[4], t));
		graph.addEdge(town[4], t, 6, "Road_6");
		assertEquals(true, graph.containsEdge(town[4], t));
	}

	@Test
	void testAddVertex() {
		Town newTown = new Town("Town_X");
		assertEquals(false, graph.containsVertex(newTown));
		graph.addVertex(newTown);
		assertEquals(true, graph.containsVertex(newTown));
	}

	@Test
	void testGetVertex() {
		assertEquals(town[1],graph.getVertex("Town_1"));
	}

	@Test
	void testContainsEdge() {
		assertEquals(true, graph.containsEdge(town[2], town[1]));
		assertEquals(false, graph.containsEdge(town[3], town[4]));
	}

	@Test
	void testContainsVertex() {
		assertEquals(true, graph.containsVertex(new Town("Town_2")));
		assertEquals(false, graph.containsVertex(new Town("Town_X")));
	}

	@Test
	void testEdgesOf() {
		Set<Road> roads = graph.edgesOf(town[1]);
		ArrayList<String> roadArrayList = new ArrayList<String>();
		for(Road road : roads)
			roadArrayList.add(road.getName());
		Collections.sort(roadArrayList);
		assertEquals("Road_1", roadArrayList.get(0));
		assertEquals("Road_2", roadArrayList.get(1));
		assertEquals("Road_6", roadArrayList.get(2));
	}

	@Test
	void testShortestPath() {
		  String beginTown = "Town_1", endTown = "Town_4";
		  Town beginIndex=null, endIndex=null;
		  Set<Town> towns = graph.vertexSet();
		  Iterator<Town> iterator = towns.iterator();
		  while(iterator.hasNext())
		  {    	
			  Town town = iterator.next();
			  if(town.getName().equals(beginTown))
				  beginIndex = town;
			  if(town.getName().equals(endTown))
				  endIndex = town;		
		  }
		  if(beginIndex != null && endIndex != null)
		  {

			  ArrayList<String> path = graph.shortestPath(beginIndex,endIndex);
			  assertNotNull(path);
			  assertTrue(path.size() > 0);
			  assertEquals("Town_1 via Road_1 to Town_2 2 mi",path.get(0).trim());
			  assertEquals("Town_2 via Road_4 to Town_4 5 mi",path.get(1).trim());
		  }
		  else
			  fail("Town names are not valid");
	}

}
